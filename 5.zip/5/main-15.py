import secrets

from flask import Flask, render_template, redirect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)

app.config['SECRET_KEY'] = secrets.token_hex(64)


class LoginForm(FlaskForm):
    astro_id = StringField('Id астронавта', validators=[DataRequired()])
    astro_password = PasswordField('Пароль астронавта', validators=[DataRequired()])
    captain_id = StringField('Id капитана', validators=[DataRequired()])
    captain_password = PasswordField('Пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/index/<title>')
def index(title: str):
    return render_template('base.html', title=title)


@app.route('/training/<prof>')
def training(prof: str):
    return render_template('training.html', prof=prof)


@app.route('/list_prof/<list_style>')
def list_prof(list_style: str):
    return render_template('proflist.html', list_style=list_style)


@app.route('/answer')
@app.route('/auto_answer')
def auto_answer():
    params = {
        'title': 'answer',
        'surname': 'Watny',
        'name': 'Mark',
        'education': 'выше среднего',
        'profession': 'штурман марсохода',
        'sex': 'male',
        'motivation': 'Всегда хотел остаться на Марсе!',
        'ready': True
    }

    return render_template('auto_answer.html', **params)


if __name__ == '__main__':
    app.run('127.0.0.1', port=8080)
