from requests import get, post, delete

print(get('http://127.0.0.1:5000/api/v2/users').json())
print(get('http://127.0.0.1:5000/api/v2/users/2').json())
print(get('http://127.0.0.1:5000/api/v2/users/78').json())
print()
print(post('http://127.0.0.1:5000/api/v2/users',
           json={'surname': 'Ivanov',
                 'name': 'Ivan',
                 'age': 15,
                 'position': 'cap',
                 'speciality': 'doctor',
                 'address': 'module_2',
                 'email': 'ivan@ivanov.ru'}).json())
print(post('http://127.0.0.1:5000/api/v2/users',
           json={'surname': 'Ivanov',
                 'name': 'Ivan',
                 'age': 15,
                 'position': 'cap',
                 'address': 'module_2',
                 'email': 'ivan@ivanov.ru'}).json())
print(post('http://127.0.0.1:5000/api/v2/users',
           json={}).json())
print(delete('http://127.0.0.1:5000/api/v2/users/999').json())
print(delete('http://127.0.0.1:5000/api/v2/users/4').json())
