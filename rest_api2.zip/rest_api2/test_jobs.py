from requests import get, post, delete

print(get('http://127.0.0.1:5000/api/v2/jobs').json())
print(get('http://127.0.0.1:5000/api/v2/jobs/2').json())
print(get('http://127.0.0.1:5000/api/v2/jobs/78').json())
print()
print(post('http://127.0.0.1:5000/api/v2/jobs',
           json={'team_leader': 2,
                 'job': 'secret',
                 'work_size': 15,
                 'collaborators': '1,3',
                 'is_finished': True}).json())
print(post('http://127.0.0.1:5000/api/v2/jobs',
           json={'team_leader': 2,
                 'job': 'secret',
                 'collaborators': '1,3',
                 'is_finished': True}).json())
print(post('http://127.0.0.1:5000/api/v2/jobs',
           json={}).json())
print(delete('http://127.0.0.1:5000/api/v2/jobs/999').json())
print(delete('http://127.0.0.1:5000/api/v2/jobs/1').json())
