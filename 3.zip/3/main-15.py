import secrets

from flask import Flask, render_template

app = Flask(__name__)

app.config['SECRET_KEY'] = secrets.token_hex(64)


@app.route('/index/<title>')
def index(title: str):
    return render_template('base.html', title=title)


@app.route('/training/<prof>')
def training(prof: str):
    return render_template('training.html', prof=prof)


@app.route('/list_prof/<list_style>')
def list_prof(list_style: str):
    return render_template('proflist.html', list_style=list_style)


if __name__ == '__main__':
    app.run('127.0.0.1', port=8080)
