from flask import Flask, render_template
from data import db_session
from data.users import User
from data.jobs import Jobs
import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/blogs.db")
    app.run()
    data = [['Scott', 'Murphy', 'Ghost', 'Back'], ["Ridley", 'Trevor', 'Nick', 'Taylor'], [21, 22, 34, 54],
            ['captain', 'assistant', 'assistant', 'assistant'], ['research engineer', 'exobiologist', 'cook', 'doctor'],
            ['module_1', 'module_1', 'module_2', 'module_1'], ["scott_chief@mars.org", "murphy@mars.org",
                                                               "ghost@mars.org", "back@mars.org"]]
    db_sess = db_session.create_session()
    for i in range(4):
        user = User()
        user.surname = data[0][i]
        user.name = data[1][i]
        user.age = data[2][i]
        user.position = data[3][i]
        user.speciality = data[4][i]
        user.address = data[5][i]
        user.email = data[6][i]
        db_sess.add(user)
        db_sess.commit()

    job = Jobs()
    job.team_leader = 1
    job.job = 'deployment of residential modules 1 and 2'
    job.work_size = 15
    job.collaborators = '2,3'
    job.start_date = datetime.datetime.today()
    job.is_finished = False
    db_sess.add(job)
    db_sess.commit()

    job1 = Jobs()
    job1.team_leader = 3
    job1.job = 'Exploration of mineral resources'
    job1.work_size = 24
    job1.collaborators = '1,2,4'
    job1.start_date = datetime.datetime.today()
    job1.is_finished = False
    db_sess.add(job1)
    db_sess.commit()
    return

@app.route("/")
def index():
    db_session.global_init('db/blogs.db')
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    return render_template("index.html", jobs=jobs)



if __name__ == '__main__':
    main()